#include <stdio.h>
// Pedro Salas Piñero, DNI: 44273547

void imprimeHola()
{
    printf("Hola!\n");
}
void imprimeChau()
{
    printf("Chau!\n");
}

int main()
{
    imprimeHola();
    imprimeHola();
    imprimeChau();
    imprimeChau();
    return 0;
}