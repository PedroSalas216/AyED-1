#include <stdio.h>

int getNum()
{
    int n;
    printf("inserte valor ");
    scanf("%d",&n);
    return n;
}

void pedirArreglo(int a[], int n_max)
{
    int i = 0;
    while (i < n_max)
    {
        a[i] = getNum();
        i++;
    }
}

struct comp_t
{
    int menores;
    int iguales;
    int mayores; 
};

struct comp_t cuantos(int a[], int tam, int elem)
{
    int i = 0;
    struct comp_t value;
    value.iguales = 0;
    value.mayores = 0;
    value.menores = 0;
    while (i < tam)
    {
        if (a[i] == elem)
        {
            value.iguales ++;
        }else
        {
            if (a[i] < elem)
            {
                value.menores ++;
            }else
            {
                value.mayores ++;
            }
        }
        i++;    
    }
    
    return value;
}

int main()
{
    int n; 
    printf("Tamaño del arreglo :");
    scanf("%d", &n);

    int a[n];
    
    pedirArreglo(a , n);
    
    int elem;
    printf("Numero a comparar: ");
    scanf("%d",&elem);

    struct comp_t value;
    value = cuantos(a,n,elem);

    printf("CANTIDAD DE: \n-Mayores: %d \n-Iguales: %d \n-Menores: %d\n",value.mayores,value.iguales,value.menores);


    return 0;
}
